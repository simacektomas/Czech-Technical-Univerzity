/**
 * TravelAgencyTrips.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package tripserviceclient;

public interface TravelAgencyTrips extends java.rmi.Remote {
    public int addTrip(tripserviceclient.Trip arg0) throws java.rmi.RemoteException;
    public tripserviceclient.Trip addTripBooking(tripserviceclient.Booking arg0) throws java.rmi.RemoteException;
}
